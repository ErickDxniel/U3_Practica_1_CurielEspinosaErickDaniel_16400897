package mx.tecnm.tepic.ladm_u3_practica1_curielespinosaerickdaniel

import android.app.Activity
import android.content.ContentValues
import android.database.sqlite.SQLiteException

class Evidencia(ida:Int, img:ByteArray) {


    val nombreBaseDeDatos   = "tareas"
    var puntero : Activity? = null
    var error               = -1

    var idEvidencia  = 0
    var idActividad  = ida
    var imagen:ByteArray=img

    fun asignarPuntero (p:MainActivity){
        puntero = p
    }

    fun mostrarTodasEvidencias(id:String):ArrayList<ByteArray>{
        var data = ArrayList<ByteArray>()
        error    = -1
        try {
            var base             = BaseDatos(puntero!!,nombreBaseDeDatos,null,1)
            var querySelect      = base.readableDatabase
            var columnas         = arrayOf("*")
            var idBuscar         = arrayOf(id)
            var cursor           = querySelect.query("EVIDENCIA",columnas,"ID_ACTIVIDAD=?",idBuscar,null,null,null)
            if(cursor.moveToFirst()){
                do{
                    data.add(cursor.getBlob(2))
                }while (cursor.moveToNext())
            }else{
                error = 3
            }

        }catch (e:SQLiteException){
            error = 1
        }

        return data
    }

    fun insertarEvidencia():Boolean{
        error = -1
        try{
            var base            = BaseDatos(puntero!!,nombreBaseDeDatos,null,1)
            var queryInsert     = base.writableDatabase
            var datos           = ContentValues()

            datos.put("ID_ACTIVIDAD",idActividad)
            datos.put("FOTO",imagen)

            var respuesta = queryInsert.insert("EVIDENCIA","ID_EVIDENCIA",datos)
            if(respuesta.toInt() == -1){
                error     = 2
                return false
            }
        }catch (e: SQLiteException){
            error=1
            return false
        }
        return true
    }




}